package com.decotdev.david_get_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DavidGetApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
