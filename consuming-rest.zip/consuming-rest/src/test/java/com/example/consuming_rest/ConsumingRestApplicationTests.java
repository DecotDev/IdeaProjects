package com.example.consuming_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumingRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
